# Portfolio
This repo is the public variant of all my projects in one convenient repositiory. Enjoy your stay
